"""Record fresh live experiments without silently using the test fixture."""
import csv
import json
from pathlib import Path
from harbour import simulate, validate_action

HERE = Path(__file__).resolve().parent


def collect_live(metadata):
    out = HERE / 'results'
    rows = []
    for seed in (11, 12, 13):
        summary = json.loads((out / f'live_seed{seed}.json').read_text())
        trace = json.loads((out / f'harbour_llm_{seed}_trace.json').read_text())
        result = summary['result']
        assert result['master_calls'] == len(trace) == 6
        for item in trace:
            assert validate_action(item['raw'], item['report']['waiting_ships']) == item['accepted']
        assert sum(item['fallback'] for item in trace) == result['invalid_outputs'] == result['fallback_uses']
        rows.append(simulate(seed, 'model'))
        rows.append(result)
    with (out / 'live_comparison.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader(); writer.writerows(rows)
    (out / 'live_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    return rows


def evaluate_live(backend, metadata):
    out = HERE / 'results'
    out.mkdir(exist_ok=True)
    for seed in (11, 12, 13):
        result, trace = simulate(seed, 'harbour_llm', backend=backend,
                                 keep_trace=True, master_schedule='storm-events')
        (out / f'harbour_llm_{seed}_trace.json').write_text(json.dumps(trace, indent=2), encoding='utf-8')
        (out / f'live_seed{seed}.json').write_text(json.dumps({
            'result': result, 'schedule': 'storm-events', 'backend': metadata['backend']}, indent=2), encoding='utf-8')
        print(result, flush=True)
    return collect_live(metadata)
