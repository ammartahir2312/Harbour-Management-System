# Stormwatch Harbour

CGD-460 Assignment 2. Python 3.10+; simulation uses only the standard library.

## Run

From this directory:

```sh
python run.py --seed 11 --policy model
python run.py --seed 11 --policy baseline
python run.py --seed 11 --policy harbour_fixture
python run.py --evaluate
python run.py --test
```

Evaluation writes `results/results.csv`, `results/results.json` and a seed-11 fixture action trace. Tests write `results/safety_tests.json`. Single runs print metrics and save the Harbour Master trace. `results/summary.csv` contains computed means for seeds 11-13 and 11-15; `results/cargo_chart.svg` is the report chart.

## Files

- `run.py`: CLI, evaluation and executable tests.
- `harbour.py`: agents, seeded scenario, simulation and strict action validator.
- `results/`: measured runs, summary, chart, safety tests and fixture trace.

## Model and assumptions

Coordinates are zero-based: x=0..23 west to east, y=0..15 north to south. B1=(3,0), B2=(9,0), B3=(15,0), B4=(21,0); warehouse=(0,15). Ten workers start at the warehouse. All cells are passable; workers may share cells. Ship queues are unbounded and FIFO among ships not currently held. Each ship carries 8 cargo units, leaves once its last unit is picked up, and has a unique integer ID.

Each run processes ticks 0..599. One `random.Random(seed)` generates all arrival intervals (inclusive 6..10 ticks) and three storm starts sampled without replacement from 60,85,...,560. This avoids overlapping storms; each lasts exactly 15 ticks. Warnings start at s-5. All events are generated before policies execute, so comparisons use the same weather and arrivals without depending on policy-specific random draws. Future events are not passed to the Harbour Master.

Tick order: arrivals and lookout update; Harbour Master decision when due; berth admission; storm contact; worker actions in stable index order; empty-ship departure. A worker can move one orthogonal cell, pick up one unit or drop off one unit per tick. Bookkeeping and quartermaster decisions are not worker actions. A storm contact at B1/B4 causes one knock-out, loses any carried unit, teleports the worker to the warehouse and prevents work for 10 ticks including the contact tick. These consequences are explicit assumptions because the brief does not define them. Ships are never newly admitted to B1/B4 during an active storm.

Quartermaster reserves available cargo and prefers the lowest numbered eligible berth; existing valid reservations persist. The baseline ignores warnings and continues assignments. The model-based policy stores a warning deadline through the end of the storm, cancels unsafe assignments, avoids B1/B4, and evacuates idle workers from those cells. Loaded workers continue returning to the warehouse. Routes leave row 0 before crossing horizontally; thus a worker travelling to B2 does not accidentally pass through B1. All policies share this movement rule. No collision or congestion model is implemented.

Cargo conservation and map bounds are asserted every tick. Tests check exact repeatability, all four specified safety categories plus parser/type attacks, valid-action acceptance, and full-run fallback equivalence. The finite seed set cannot prove universal performance.

## Live Harbour Master evaluation

The updated report uses **actual model-generated decisions from the Codex assistant in this chat**, delivered through an operator-mediated file bridge. Each running simulation paused and wrote its current report; the model read it and supplied the action JSON; the program then validated and applied that response before continuing. The response files were generated during the run and were not created by `fixture()`.

Seeds 11,12,13 each made six live decisions: warning onset and storm end for three storms. Eighteen proposals were accepted, comprising nine warnings and nine holds. Cargo was 130,130,128 with no knock-outs, invalid outputs or fallbacks. These are chat-mediated live results, **not an autonomous API benchmark and not a Colab execution**. Exact model ID, temperature and sampling seed were not independently recorded. See `results/live_metadata.json`, `live_comparison.csv`, `live_seed*.json`, `harbour_llm_*_trace.json` and all paired `results/live_bridge` request/response files. Never count replaying those files as new live inference.

### Direct live inference on Colab or Kaggle

Open `Live_Harbour_Master.ipynb` in Colab, select a GPU runtime and run the cells. Upload `Stormwatch_Harbour_Live_Code.zip` when prompted. For Kaggle, enable Internet, attach that ZIP as a dataset and set `ZIP_PATH` in the notebook. The notebook downloads `Qwen/Qwen2.5-0.5B-Instruct`, generates each response with model weights, validates raw text, writes fresh measured results and regenerates the PDF. It does not replay the bridge responses. No paid API key is required for that model route. A GPU is preferable; CPU inference will be slower. This notebook is supplied but was not executed in the chat environment.

The model card and reference implementation are at https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct. The notebook records the actual model revision and generation settings when executed. Its outputs can differ from the supplied chat-mediated results, including malformed outputs that correctly trigger fallback.

### Live hosted endpoint

Alternatively set `HARBOUR_BASE_URL` to your provider's OpenAI-compatible base URL (including `/v1` where appropriate), `HARBOUR_MODEL` to the model identifier and `HARBOUR_API_KEY` to the secret in your environment, then run:

```sh
python run.py --seed 11 --policy harbour_llm --live-api --master-schedule storm-events
```

Use seeds 12 and 13 too. This endpoint adapter is included; no endpoint API was used for the supplied results. Keys are never written into result files. Hosted provider charges and access depend on your account.

### Live chat bridge

```sh
python run.py --seed 11 --policy harbour_llm --bridge results/new_live_bridge --master-schedule storm-events
```

Use an empty directory. At each WAITING message, an external LLM must read the corresponding request and write its action into the matching `.response.json` file. The program pauses for up to 900 seconds. Stale request/response files are refused to prevent accidental replay being presented as live inference. The bridge needs an external operator or model runner; it does not automatically call a model by itself.

### Retained offline tests

`harbour_fixture` is a deterministic scripted test double, **not an LLM**. It returns warn_storm when a warning is present or no ship is waiting; otherwise it holds the first waiting ship for 10 ticks. It is queried every 10 ticks and at warning onset. A warning action only relays genuine sensor information; it does not create a false storm. Both Harbour Master modes retain the model-based worker controller as the safety layer. Valid holds affect admission; invalid proposals execute no action and use that controller. There is no privileged close, release-cargo or approval-bypass action.

Allowed JSON: `{"action":"warn_storm"}` or `{"action":"hold_ship","ship_id":3}`. Exact key sets are required, ship IDs must be integers (not booleans) and must appear in the current waiting list. Bare function calls, unknown actions, extra keys, unknown ships, bad JSON, command failures and timeouts are rejected. Output is parsed with `json.loads`, never `eval`.

An external-command model adapter is also supported:

```sh
python run.py --seed 11 --policy harbour_llm --llm-command python my_adapter.py
```

An external adapter must read one JSON object from stdin containing trusted `instruction` and untrusted `report`, call the chosen model, and print only its JSON action. Use environment variables for secrets. The historical `results.csv` retains baseline, model and fixture runs; `live_comparison.csv` is the live comparison. The updated live report does not use fixture measurements as LLM evidence. `report_builder.py` regenerates the PDF from recorded live files and requires ReportLab.

## Submission status

The PDF is a worked draft with an honest AI declaration. It needs your own review and understanding. No student name or ID was invented. The assignment requests a hosted repository link: this local package does not provide a hosted URL. Create a repository in your account, upload these files and add its real URL to the submission. Review the declaration and record only checks you actually perform. No credentials are included.

The main task instructions request seeds 11-13 while the settings table says 11-15. All five are supplied; the report uses 11-13 as its primary comparison.
